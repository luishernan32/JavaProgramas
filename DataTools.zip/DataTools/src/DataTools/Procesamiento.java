package DataTools;

import javax.swing.JOptionPane;

public abstract class Procesamiento {
	
	public void Operar()
	{
		int seleccionar=0;
        int bandera=0;
        do
        {
        	
            try
            {
                seleccionar=Integer.parseInt(JOptionPane.showInputDialog(null," Selecciona el n�mero correspondiente para la opci�n indicada\n \n "+
                        "1. Arreglo de n�meros decimales separados por guion, p ej: �10-25.3-45-14.68�\n "+
                        "2. Validaci�n, validar el formato de los n�meros\n "+
                        "3. Cantidad de elementos del arreglo 'N'(sumatoria y raiz cuadrada) \n "+
                        "4. Para salir \n\n"));
                
                if(seleccionar==1)
                {
                    Procesamiento objeto=new ArregloSeparadoPorGuion();
                    objeto.Responsabilidad();
                }
                else if(seleccionar==2)
                {
                    Procesamiento objeto=new Validacion();
                    objeto.Responsabilidad();
                }
                else if(seleccionar==3)
                {
                    Procesamiento objeto=new PuntoDos();
                    objeto.Responsabilidad();
                }
                else if(seleccionar==4)
                {
                    bandera=2;
                }
            }
            catch(NumberFormatException e){}
        }while(bandera!=2);
	}
	public abstract void Responsabilidad();
	

}
