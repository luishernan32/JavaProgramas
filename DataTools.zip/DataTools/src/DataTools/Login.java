package DataTools;

public class Login {
	public static void main(String[] args) 
	{
		Procesamiento objeto=new Validacion();
		objeto.Operar();
	}

}
