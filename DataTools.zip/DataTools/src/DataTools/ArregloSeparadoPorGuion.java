package DataTools;

import javax.swing.JOptionPane;

public class ArregloSeparadoPorGuion extends Procesamiento {
	@Override
	public void Responsabilidad()
	{
		double[] numeros=new double[3];
		JOptionPane.showMessageDialog(null, "Arreglo de n�meros decimales separados por guion");
		for (int i = 0; i < numeros.length; i++) {
            try {
                numeros[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el "+i+ " elemento del arreglo"));
                if(numeros[i]<0)
                {
                	JOptionPane.showMessageDialog(null,"Ingresaste un valor negativo, solo se aceptan positivos");
                	i--;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingresa un decimal");
                System.out.println("Ingresa un decimal");
                i--;
            }

        }
		JOptionPane.showMessageDialog(null,"Los valores insertados se registrar�n en la consola");
		System.out.println("**********************************************");
		System.out.println("");
        System.out.printf("%2f-%2f-%2f", numeros[0], numeros[1], numeros[2]);
        System.out.println("");
        System.out.println("**********************************************");
        System.out.println("");
	}

}
