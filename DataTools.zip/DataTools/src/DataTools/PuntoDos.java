package DataTools;



import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class PuntoDos extends Procesamiento {
    
    	@Override
    	public void Responsabilidad()
    	{
    		int suma=0;
        	int N = 0;

            do {

                N = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el valor de N"));
                
               /* if(N>7)
                {
                    JOptionPane.showMessageDialog(null,"Te vas a demorar digitando el arreglo");
                }*/
                 if (N > 0) {

                    try
                    {
                        double arreglo[] = new double[N];
                    JOptionPane.showMessageDialog(null,"Este es el valor de N: "+N);
                    System.out.println("-------------------------");
                    System.out.println("Est� es el valor de N= " + N);
                    System.out.println("-------------------------");

                    for (int i = 0; i < arreglo.length; i++) {
                        arreglo[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingresa los valores del arreglo"));
                        if(arreglo[i]<0)
                        {
                            JOptionPane.showMessageDialog(null,"Introduciste un n�mero negativo solo se permiten n�meros positivos vuelve a ingresar ese valor");
                            i--;
                        }
                    }
                    System.out.println("Est� es el arreglo ingresado");
                    for (int i = 0; i < arreglo.length; i++) {
                        //JOptionPane.showMessageDialog(null,arreglo[i] + " - ");
                        System.out.print(arreglo[i] + " - ");
                    }
                    
                    for (int i = 0; i < arreglo.length; i++) {
    					suma+=arreglo[i];
    				}
                    JOptionPane.showMessageDialog(null,"Ra�z cuadrada de la sumatoria es: \n "+Math.sqrt(suma));
                        
                    System.out.println("\n*****************************************************");    
                    System.out.println("Ra�z cuadrada de la sumatoria es: \n "+Math.sqrt(suma));
                    System.out.println("*****************************************************");
                    }
                    catch(NumberFormatException e)
                            {
                                System.out.println("Ingresaste un valor no valido");
                            }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"NO PASA LA VALIDACI�N Introduciste un n�mero negativo");
                }

            } while (N < 0);

            System.out.println("\n");
    	}
    	
        
    }


