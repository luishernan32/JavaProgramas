package DataTools;

import javax.swing.JOptionPane;

public class Validacion extends Procesamiento {
	
	@Override
	public void Responsabilidad()
	{
		//String paso, npaso = "";
	    int elementos=0;
		JOptionPane.showMessageDialog(null, "Ingresa el n�meros de elementos para validar");
		elementos=Integer.parseInt(JOptionPane.showInputDialog("Ingresa la cantidad de elementos por validar"));
		          
	    String[] numeros = new String[elementos];
	   // Scanner teclado = new Scanner(System.in);
	    for (int i = 0; i < numeros.length; i++) {
	      //System.out.println("Introduce numero entero");
	        //numeros[i]=teclado.nextLine();
	    	JOptionPane.showMessageDialog(null, "Ingresa punto o coma al decimal para probar la validaci�n");
	        numeros[i] = JOptionPane.showInputDialog("Introduce el n�mero");

	        if (numeros[i].contains(",")) {
	            JOptionPane.showMessageDialog(null,"El n�mero "+numeros[i]+"  No paso la validaci�n");
	            System.out.println("-----------------------------------------------------");
	            System.out.println("Numero Invalido: " + numeros[i] + " No paso la validaci�n");
	            System.out.println("-----------------------------------------------------");
	        } else {
	            JOptionPane.showMessageDialog(null,"El n�mero "+numeros[i]+" Paso la validaci�n");
	            System.out.println("-----------------------------------------------------");
	            System.out.println("Numero valido: " + numeros[i] + "  Paso la validaci�n");
	            System.out.println("-----------------------------------------------------");
	        }
	        
	        
	        
	        
	        System.out.println(numeros[0] + " - " + numeros[1]+ " - " + numeros[2]
	        		+ " - " + numeros[3]+ " - " + numeros[4]+ " - " + numeros[5]
	        		+ " - " + numeros[6]+ " - " + numeros[7]+ " - " + numeros[8]);
	        //System.out.printf("%02f-%02f",numeros[0],numeros[1]);

	    }
	}

			
		
	}
	
		
